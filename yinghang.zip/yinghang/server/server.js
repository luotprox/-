const express = require('express')
const cors = require('cors')
const path = require('path')
const pool = require('./db')

const app = express()
app.use(cors())
app.use(express.json())
app.use(express.static(path.join(__dirname, '..')))

// ====== 验证码存储（内存） ======
const verificationCodes = new Map()

// ====== 发送验证码 ======
app.post('/api/send-code', async (req, res) => {
  try {
    const { phone } = req.body
    if (!phone || !/^1\d{10}$/.test(phone)) return res.json({ code: 1, msg: '请输入有效的手机号' })

    const existing = verificationCodes.get(phone)
    if (existing && Date.now() - existing.sentAt < 60000) {
      const remaining = Math.ceil((60000 - (Date.now() - existing.sentAt)) / 1000)
      return res.json({ code: 1, msg: `请 ${remaining} 秒后再试` })
    }

    const code = String(Math.floor(100000 + Math.random() * 900000))
    verificationCodes.set(phone, { code, sentAt: Date.now() })

    console.log(`[验证码] ${phone} -> ${code}`)
    res.json({ code: 0, msg: '验证码已发送', data: { code } })
  } catch (e) {
    res.json({ code: 1, msg: '服务器错误: ' + e.message })
  }
})

// ====== 用户注册 ======
app.post('/api/register', async (req, res) => {
  try {
    const { username, password, phone, code } = req.body
    if (!username || !password) return res.json({ code: 1, msg: '请填写用户名和密码' })
    if (!phone) return res.json({ code: 1, msg: '请填写手机号' })

    const stored = verificationCodes.get(phone)
    if (!stored) return res.json({ code: 1, msg: '请先获取验证码' })
    if (stored.code !== code) return res.json({ code: 1, msg: '验证码错误' })
    if (Date.now() - stored.sentAt > 60000) {
      verificationCodes.delete(phone)
      return res.json({ code: 1, msg: '验证码已过期，请重新获取' })
    }
    verificationCodes.delete(phone)

    const [rows] = await pool.execute('SELECT id FROM users WHERE username = ?', [username])
    if (rows.length > 0) return res.json({ code: 1, msg: '用户名已存在' })

    await pool.execute(
      'INSERT INTO users (username, password, phone, balance) VALUES (?, ?, ?, 1000.00)',
      [username, password, phone]
    )
    res.json({ code: 0, msg: '注册成功' })
  } catch (e) {
    res.json({ code: 1, msg: '服务器错误: ' + e.message })
  }
})

// ====== 用户登录 ======
app.post('/api/login', async (req, res) => {
  try {
    const { username, password } = req.body
    if (!username || !password) return res.json({ code: 1, msg: '请填写用户名和密码' })

    const [rows] = await pool.execute(
      'SELECT id, username, balance, role, frozen FROM users WHERE username = ? AND password = ?',
      [username, password]
    )
    if (rows.length === 0) return res.json({ code: 1, msg: '用户名或密码错误' })
    if (rows[0].role === 'admin') return res.json({ code: 1, msg: '请使用管理员登录入口' })

    const u = rows[0]
    res.json({ code: 0, data: { id: u.id, username: u.username, balance: u.balance, role: u.role, frozen: u.frozen } })
  } catch (e) {
    res.json({ code: 1, msg: '服务器错误: ' + e.message })
  }
})

// ====== 管理员登录 ======
app.post('/api/admin/login', async (req, res) => {
  try {
    const { username, password } = req.body
    if (!username || !password) return res.json({ code: 1, msg: '请填写管理员账号和密码' })

    const [rows] = await pool.execute(
      'SELECT id, username, role FROM users WHERE username = ? AND password = ? AND role = ?',
      [username, password, 'admin']
    )
    if (rows.length === 0) return res.json({ code: 1, msg: '管理员账号或密码错误' })

    const u = rows[0]
    res.json({ code: 0, data: { id: u.id, username: u.username, role: u.role } })
  } catch (e) {
    res.json({ code: 1, msg: '服务器错误: ' + e.message })
  }
})

// ====== 获取用户信息 ======
app.get('/api/user/:id', async (req, res) => {
  try {
    const [rows] = await pool.execute(
      'SELECT id, username, balance, role, frozen FROM users WHERE id = ?',
      [req.params.id]
    )
    if (rows.length === 0) return res.json({ code: 1, msg: '用户不存在' })

    const u = rows[0]
    res.json({ code: 0, data: { id: u.id, username: u.username, balance: u.balance, role: u.role, frozen: u.frozen } })
  } catch (e) {
    res.json({ code: 1, msg: '服务器错误: ' + e.message })
  }
})

// ====== 存款 ======
app.post('/api/deposit', async (req, res) => {
  try {
    const { userId, amount } = req.body
    if (!amount || amount <= 0) return res.json({ code: 1, msg: '金额必须大于0' })

    const [rows] = await pool.execute('SELECT id, balance FROM users WHERE id = ?', [userId])
    if (rows.length === 0) return res.json({ code: 1, msg: '用户不存在' })

    const bal = parseFloat(rows[0].balance)
    const newBalance = parseFloat((bal + amount).toFixed(2))
    await pool.execute('UPDATE users SET balance = ? WHERE id = ?', [newBalance, userId])
    await pool.execute(
      'INSERT INTO transactions (user_id, type, amount, balance_after) VALUES (?, ?, ?, ?)',
      [userId, 'deposit', amount, newBalance]
    )
    res.json({ code: 0, msg: '存款成功', balance: newBalance })
  } catch (e) {
    res.json({ code: 1, msg: '服务器错误: ' + e.message })
  }
})

// ====== 取款 ======
app.post('/api/withdraw', async (req, res) => {
  try {
    const { userId, amount, note } = req.body
    if (!amount || amount <= 0) return res.json({ code: 1, msg: '金额必须大于0' })

    const [rows] = await pool.execute('SELECT id, balance, frozen FROM users WHERE id = ?', [userId])
    if (rows.length === 0) return res.json({ code: 1, msg: '用户不存在' })
    if (rows[0].frozen) return res.json({ code: 1, msg: '账户已被冻结，无法取款' })
    const wBal = parseFloat(rows[0].balance)
    if (wBal < amount) return res.json({ code: 1, msg: '余额不足' })

    const newBalance = parseFloat((wBal - amount).toFixed(2))
    await pool.execute('UPDATE users SET balance = ? WHERE id = ?', [newBalance, userId])
    await pool.execute(
      'INSERT INTO transactions (user_id, type, amount, balance_after, note) VALUES (?, ?, ?, ?, ?)',
      [userId, 'withdraw', amount, newBalance, note || '']
    )
    res.json({ code: 0, msg: '取款成功', balance: newBalance })
  } catch (e) {
    res.json({ code: 1, msg: '服务器错误: ' + e.message })
  }
})

// ====== 转账 ======
app.post('/api/transfer', async (req, res) => {
  try {
    const { userId, targetName, amount, note } = req.body
    if (!amount || amount <= 0) return res.json({ code: 1, msg: '金额必须大于0' })
    if (!targetName) return res.json({ code: 1, msg: '请输入对方用户ID或昵称' })

    const [fromRows] = await pool.execute('SELECT id, balance, frozen, username FROM users WHERE id = ?', [userId])
    if (fromRows.length === 0) return res.json({ code: 1, msg: '转出用户不存在' })
    if (fromRows[0].frozen) return res.json({ code: 1, msg: '账户已被冻结，无法转账' })

    const targetId = parseInt(targetName)
    let [toRows] = await pool.execute('SELECT id, username FROM users WHERE id = ?', [targetId])
    if (toRows.length === 0) {
      [toRows] = await pool.execute('SELECT id, username FROM users WHERE username = ?', [targetName])
    }
    if (toRows.length === 0) return res.json({ code: 1, msg: '对方用户不存在' })
    if (fromRows[0].id === toRows[0].id) return res.json({ code: 1, msg: '不能转账给自己' })
    const fromBal = parseFloat(fromRows[0].balance)
    const toBal = parseFloat(toRows[0].balance)
    if (fromBal < amount) return res.json({ code: 1, msg: '余额不足' })

    const fromNewBal = parseFloat((fromBal - amount).toFixed(2))
    const toNewBal = parseFloat((toBal + amount).toFixed(2))

    await pool.execute('UPDATE users SET balance = ? WHERE id = ?', [fromNewBal, userId])
    await pool.execute('UPDATE users SET balance = ? WHERE id = ?', [toNewBal, toRows[0].id])

    await pool.execute(
      'INSERT INTO transactions (user_id, type, amount, balance_after, target_name, note) VALUES (?, ?, ?, ?, ?, ?)',
      [userId, 'transfer_out', amount, fromNewBal, toRows[0].username, note || '']
    )
    await pool.execute(
      'INSERT INTO transactions (user_id, type, amount, balance_after, target_name, note) VALUES (?, ?, ?, ?, ?, ?)',
      [toRows[0].id, 'transfer_in', amount, toNewBal, fromRows[0].username, note || '']
    )

    res.json({ code: 0, msg: '转账成功', balance: fromNewBal })
  } catch (e) {
    res.json({ code: 1, msg: '服务器错误: ' + e.message })
  }
})

// ====== 修改密码 ======
app.post('/api/change-password', async (req, res) => {
  try {
    const { userId, oldPassword, newPassword } = req.body
    if (!oldPassword || !newPassword) return res.json({ code: 1, msg: '请填写完整' })
    if (newPassword.length < 3) return res.json({ code: 1, msg: '新密码至少3位' })

    const [rows] = await pool.execute('SELECT password FROM users WHERE id = ?', [userId])
    if (rows.length === 0) return res.json({ code: 1, msg: '用户不存在' })
    if (rows[0].password !== oldPassword) return res.json({ code: 1, msg: '当前密码错误' })

    await pool.execute('UPDATE users SET password = ? WHERE id = ?', [newPassword, userId])
    res.json({ code: 0, msg: '密码修改成功' })
  } catch (e) {
    res.json({ code: 1, msg: '服务器错误: ' + e.message })
  }
})

// ====== 交易记录 ======
app.get('/api/transactions/:userId', async (req, res) => {
  try {
    const [rows] = await pool.execute(
      'SELECT * FROM transactions WHERE user_id = ? ORDER BY created_at DESC',
      [req.params.userId]
    )
    res.json({ code: 0, data: rows })
  } catch (e) {
    res.json({ code: 1, msg: '服务器错误: ' + e.message })
  }
})

// ====== 管理员：获取所有用户 ======
app.get('/api/admin/users', async (req, res) => {
  try {
    const [rows] = await pool.execute(
      'SELECT id, username, balance, role, frozen, created_at FROM users ORDER BY id ASC'
    )
    res.json({ code: 0, data: rows })
  } catch (e) {
    res.json({ code: 1, msg: '服务器错误: ' + e.message })
  }
})

// ====== 管理员：删除用户 ======
app.delete('/api/admin/user/:id', async (req, res) => {
  try {
    const [rows] = await pool.execute('SELECT role FROM users WHERE id = ?', [req.params.id])
    if (rows.length === 0) return res.json({ code: 1, msg: '用户不存在' })
    if (rows[0].role === 'admin') return res.json({ code: 1, msg: '不能删除管理员' })

    await pool.execute('DELETE FROM users WHERE id = ?', [req.params.id])
    res.json({ code: 0, msg: '用户已删除' })
  } catch (e) {
    res.json({ code: 1, msg: '服务器错误: ' + e.message })
  }
})

// ====== 管理员：添加余额 ======
app.post('/api/admin/user/add-balance', async (req, res) => {
  try {
    const { userId, amount } = req.body
    if (!amount || amount <= 0) return res.json({ code: 1, msg: '金额必须大于0' })

    const [rows] = await pool.execute('SELECT id, balance FROM users WHERE id = ?', [userId])
    if (rows.length === 0) return res.json({ code: 1, msg: '用户不存在' })

    const aBal = parseFloat(rows[0].balance)
    const newBalance = parseFloat((aBal + amount).toFixed(2))
    await pool.execute('UPDATE users SET balance = ? WHERE id = ?', [newBalance, userId])
    res.json({ code: 0, msg: '添加余额成功' })
  } catch (e) {
    res.json({ code: 1, msg: '服务器错误: ' + e.message })
  }
})

// ====== 管理员：扣除余额 ======
app.post('/api/admin/user/sub-balance', async (req, res) => {
  try {
    const { userId, amount } = req.body
    if (!amount || amount <= 0) return res.json({ code: 1, msg: '金额必须大于0' })

    const [rows] = await pool.execute('SELECT id, balance FROM users WHERE id = ?', [userId])
    if (rows.length === 0) return res.json({ code: 1, msg: '用户不存在' })

    const sBal = parseFloat(rows[0].balance)
    const newBalance = parseFloat((sBal - amount).toFixed(2))
    await pool.execute('UPDATE users SET balance = ? WHERE id = ?', [newBalance, userId])
    res.json({ code: 0, msg: '扣除余额成功' })
  } catch (e) {
    res.json({ code: 1, msg: '服务器错误: ' + e.message })
  }
})

// ====== 管理员：冻结/解冻 ======
app.post('/api/admin/user/toggle-freeze', async (req, res) => {
  try {
    const { userId } = req.body
    const [rows] = await pool.execute('SELECT frozen FROM users WHERE id = ?', [userId])
    if (rows.length === 0) return res.json({ code: 1, msg: '用户不存在' })

    const newFrozen = rows[0].frozen ? 0 : 1
    await pool.execute('UPDATE users SET frozen = ? WHERE id = ?', [newFrozen, userId])
    res.json({ code: 0, msg: newFrozen ? '账户已冻结' : '账户已解冻' })
  } catch (e) {
    res.json({ code: 1, msg: '服务器错误: ' + e.message })
  }
})

app.listen(3000, () => {
  console.log('银行存款机后端服务已启动: http://127.0.0.1:3000')
})
