const mysql = require('mysql2/promise')

const pool = mysql.createPool({
  host: '127.0.0.1',
  port: 3306,
  user: 'root',
  password: '123456',
  database: 'bank_db',
  waitForConnections: true,
  connectionLimit: 10,
  charset: 'utf8mb4'
})

module.exports = pool
