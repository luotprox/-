const mysql = require('mysql2/promise')

async function initDB() {
  let connection
  try {
    // 先连接到MySQL服务器（不指定数据库）
    connection = await mysql.createConnection({
      host: '127.0.0.1',
      port: 3306,
      user: 'root',
      password: '123456'
    })

    console.log('正在创建数据库...')
    await connection.query('CREATE DATABASE IF NOT EXISTS bank_db DEFAULT CHARSET utf8mb4 COLLATE utf8mb4_unicode_ci')
    await connection.query('USE bank_db')

    console.log('正在创建用户表...')
    await connection.query(`
      CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        phone VARCHAR(20),
        balance DECIMAL(10, 2) DEFAULT 1000.00,
        role VARCHAR(20) DEFAULT 'user',
        frozen TINYINT(1) DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    `)

    console.log('正在创建交易记录表...')
    await connection.query(`
      CREATE TABLE IF NOT EXISTS transactions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        type VARCHAR(20) NOT NULL,
        amount DECIMAL(10, 2) NOT NULL,
        balance_after DECIMAL(10, 2) NOT NULL,
        target_name VARCHAR(50),
        note VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_user_id (user_id)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    `)

    console.log('正在创建贷款记录表...')
    await connection.query(`
      CREATE TABLE IF NOT EXISTS loans (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        loan_amount DECIMAL(10, 2) NOT NULL,
        remaining_debt DECIMAL(10, 2) NOT NULL,
        status VARCHAR(20) DEFAULT 'active',
        last_interest_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_user_id (user_id),
        INDEX idx_status (status)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    `)

    console.log('正在创建异常手机号表...')
    await connection.query(`
      CREATE TABLE IF NOT EXISTS abnormal_phones (
        id INT AUTO_INCREMENT PRIMARY KEY,
        phone VARCHAR(20) NOT NULL UNIQUE,
        reason VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    `)

    console.log('正在插入管理员账号...')
    await connection.query(`
      INSERT IGNORE INTO users (username, password, role) VALUES ('manage', '123456', 'admin')
    `)

    console.log('✅ 数据库初始化成功！')
    console.log('管理员账号: manage')
    console.log('管理员密码: 123456')
  } catch (e) {
    console.error('❌ 数据库初始化失败:', e.message)
    console.log('\n请检查：')
    console.log('1. MySQL服务是否已启动')
    console.log('2. 数据库配置（host/port/user/password）是否正确')
    process.exit(1)
  } finally {
    if (connection) {
      await connection.end()
    }
  }
}

initDB()
