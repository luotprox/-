银行存款机 — 安装包制作说明
================================

你需要在电脑上安装以下工具，才能编译安装包：

1. InnoSetup (免费)
   - 下载: https://jrsoftware.org/isdl.php
   - 安装后打开 setup.iss，点击 Build → Compile

2. NSSM (免费，用于注册 Windows 服务)
   - 下载: https://nssm.cc/download
   - 将 nssm-2.24\win64\nssm.exe 复制到 installer\utils\ 目录
   
编译步骤：
1. 下载并安装 InnoSetup
2. 下载 NSSM 并放好 nssm.exe
3. 双击 setup.iss 打开 → Build → Compile
4. 生成的安装包在 installer\output\ 目录下

安装后效果：
- 银行存款机会注册为 Windows 系统服务，开机自启
- 桌面会有快捷方式，双击打开浏览器即可使用
- 在 services.msc 中可以管理服务的启停
- 程序崩溃后会自动重启

在别人电脑上安装前需要：
- 先安装 Node.js (https://nodejs.org/) LTS 版本
- 先安装 MySQL Community Server (https://dev.mysql.com/downloads/mysql/)
  并设置 root 密码为 123456，或修改 server\db.js 中的配置
