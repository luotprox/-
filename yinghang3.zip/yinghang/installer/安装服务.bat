@echo off
chcp 65001 >nul
title 银行存款机 — 服务安装

:: 检查管理员权限
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo [错误] 请右键选择"以管理员身份运行"
    pause
    exit /b 1
)

echo ========================================
echo   银行存款机 — 一键安装服务（开机自启）
echo ========================================
echo.

:: 检查 Node.js
where node >nul 2>&1
if %errorLevel% neq 0 (
    echo [!] 未检测到 Node.js，请先安装: https://nodejs.org/
    pause
    exit /b 1
)

:: 检查 MySQL
sc query MySQL80 >nul 2>&1
if %errorLevel% neq 0 (
    sc query MySQL >nul 2>&1
    if %errorLevel% neq 0 (
        echo [!] 未检测到 MySQL 服务
        echo     请先安装 MySQL: https://dev.mysql.com/downloads/mysql/
        echo     或手动启动 MySQL 后再运行本脚本
        pause
        exit /b 1
    )
)

:: 检查 NSSM
set NSSM=utils\nssm.exe
if not exist %NSSM% (
    echo [!] 缺少 nssm.exe
    echo     请从 https://nssm.cc/download 下载 nssm-2.24\win64\nssm.exe
    echo     放到 %~dp0utils\ 目录
    pause
    exit /b 1
)

set APP_DIR=%~dp0..\server

:: 安装 npm 依赖
echo [1/4] 安装 npm 依赖...
cd /d "%APP_DIR%"
call npm install
if %errorLevel% neq 0 (
    echo [错误] npm install 失败
    pause
    exit /b 1
)

:: 初始化数据库
echo [2/4] 初始化数据库...
node init-db.js
if %errorLevel% neq 0 (
    echo [错误] 数据库初始化失败，请确认 MySQL 已启动并且配置正确
    pause
    exit /b 1
)

:: 如果服务已存在，先删除
echo [3/4] 注册 Windows 服务...
%NSSM% stop 银行存款机 >nul 2>&1
%NSSM% remove 银行存款机 confirm >nul 2>&1

:: 注册服务
%NSSM% install 银行存款机 "%ProgramFiles%\nodejs\node.exe" "%APP_DIR%\server.js"
%NSSM% set 银行存款机 AppDirectory "%APP_DIR%"
%NSSM% set 银行存款机 Start SERVICE_AUTO_START
%NSSM% set 银行存款机 AppThrottle 0
%NSSM% set 银行存款机 AppStdout "%APP_DIR%\server_out.log"
%NSSM% set 银行存款机 AppStderr "%APP_DIR%\server_err.log"
%NSSM% set 银行存款机 AppRotateFiles 1
%NSSM% set 银行存款机 DisplayName "银行存款机后端服务"

:: 启动服务
%NSSM% start 银行存款机

echo [4/4] 服务已启动！

echo.
echo ========================================
echo   ✓ 安装成功！
echo   服务名称: 银行存款机
echo   访问地址: http://127.0.0.1:3001/
echo   管理命令:
echo     net start 银行存款机   启动服务
echo     net stop 银行存款机    停止服务
echo ========================================
echo.
start http://127.0.0.1:3001/
pause
