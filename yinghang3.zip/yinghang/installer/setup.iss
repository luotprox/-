; 银行存款机 安装程序 — InnoSetup 脚本
; 使用方法：安装 InnoSetup (https://jrsoftware.org/isdl.php)，右键本文件 → Compile

#define MyAppName "银行存款机"
#define MyAppVersion "1.0.0"
#define MyAppPublisher "银行存款机"
#define MyAppURL "http://127.0.0.1:3001"

[Setup]
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\{#MyAppName}
DefaultGroupName={#MyAppName}
OutputDir=.\output
OutputBaseFilename=银行存款机_安装包
Compression=lzma2
SolidCompression=yes
UninstallDisplayIcon={app}\银行存储机.html
PrivilegesRequired=admin
DisableProgramGroupPage=yes
DisableWelcomePage=no

[Languages]
Name: "chinesesimplified"; MessagesFile: "compiler:Languages\ChineseSimplified.isl"

[Files]
; 项目文件
Source: "..\银行存储机.html"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\server\*"; DestDir: "{app}\server"; Flags: ignoreversion recursesubdirs; Excludes: "node_modules"
; NSSM（用于注册 Windows 服务）
Source: "utils\nssm.exe"; DestDir: "{app}\utils"; Flags: ignoreversion

[Dirs]
Name: "{app}\server\node_modules"

[Run]
; 安装 npm 依赖
Filename: "{cmd}"; Parameters: "/c cd /d ""{app}\server"" && npm install"; StatusMsg: "正在安装 Node.js 依赖..."
; 初始化数据库
Filename: "{cmd}"; Parameters: "/c cd /d ""{app}\server"" && node init-db.js"; StatusMsg: "正在初始化数据库..."
; 注册 Windows 服务（开机自启）
Filename: "{app}\utils\nssm.exe"; Parameters: "install 银行存款机 ""C:\Program Files\nodejs\node.exe"" ""{app}\server\server.js"""; StatusMsg: "正在注册系统服务（开机自启）..."
; 设置服务自动启动
Filename: "{app}\utils\nssm.exe"; Parameters: "set 银行存款机 Start SERVICE_AUTO_START"; Flags: runhidden
; 设置服务的工作目录
Filename: "{app}\utils\nssm.exe"; Parameters: "set 银行存款机 AppDirectory ""{app}\server"""; Flags: runhidden
; 设置服务崩溃后自动重启
Filename: "{app}\utils\nssm.exe"; Parameters: "set 银行存款机 AppThrottle 0"; Flags: runhidden
; 启动服务
Filename: "{app}\utils\nssm.exe"; Parameters: "start 银行存款机"; StatusMsg: "正在启动服务..."

[UninstallRun]
; 卸载时停止并删除服务
Filename: "{app}\utils\nssm.exe"; Parameters: "stop 银行存款机"; Flags: runhidden
Filename: "{app}\utils\nssm.exe"; Parameters: "remove 银行存款机 confirm"; Flags: runhidden

[Icons]
Name: "{group}\银行存款机"; Filename: "http://127.0.0.1:3001/"; IconFilename: "{app}\银行存储机.html"
Name: "{group}\管理工具\查看服务状态"; Filename: "services.msc"
Name: "{group}\管理工具\重启服务"; Filename: "{app}\utils\nssm.exe"; Parameters: "restart 银行存款机"
Name: "{group}\管理工具\停止服务"; Filename: "{app}\utils\nssm.exe"; Parameters: "stop 银行存款机"
Name: "{group}\卸载银行存款机"; Filename: "{uninstallexe}"
Name: "{commondesktop}\银行存款机"; Filename: "http://127.0.0.1:3001/"; IconFilename: "{app}\银行存储机.html"

[Registry]
; 将安装目录写入注册表，方便后续维护
Root: "HKLM"; Subkey: "SOFTWARE\银行存款机"; ValueType: string; ValueName: "InstallPath"; ValueData: "{app}"; Flags: uninsdeletekey

[Code]
function IsAppRunning(const AppName: string): Boolean;
var
  ResultCode: Integer;
begin
  Exec(ExpandConstant('{app}\utils\nssm.exe'), ExpandConstant('status ' + AppName), '',
       SW_HIDE, ewWaitUntilTerminated, ResultCode);
  Result := ResultCode = 0;
end;

function InitializeSetup: Boolean;
var
  ResultCode: Integer;
begin
  Result := True;

  if not FileExists(ExpandConstant('{win}\system32\nslookup.exe')) then
  begin
    MsgBox('此安装程序需要 Windows 系统。', mbError, MB_OK);
    Result := False;
    Exit;
  end;

  Exec('cmd.exe', '/c node --version > nul 2>&1', '', SW_HIDE, ewWaitUntilTerminated, ResultCode);
  if ResultCode <> 0 then
  begin
    if MsgBox('未检测到 Node.js！' #13#13 '点击"是"自动打开 Node.js 下载页面（请下载 LTS 版本并安装）' #13#13 '安装完成后，重新运行本安装程序。',
              mbConfirmation, MB_YESNO) = IDYES then
    begin
      ShellExec('open', 'https://nodejs.org/', '', '', SW_SHOW, ewNoWait, ResultCode);
    end;
    Result := False;
    Exit;
  end;

end;

procedure CurStepChanged(CurStep: TSetupStep);
var
  ResultCode: Integer;
begin
  if CurStep = ssPostInstall then
  begin
    if IsAppRunning('银行存款机') then
    begin
      Exec(ExpandConstant('{app}\utils\nssm.exe'), 'restart 银行存款机', '',
           SW_HIDE, ewWaitUntilTerminated, ResultCode);
    end;
  end;
end;

procedure CurUninstallStepChanged(CurUninstallStep: TUninstallStep);
var
  ResultCode: Integer;
begin
  if CurUninstallStep = usUninstall then
  begin
    MsgBox('卸载将删除所有数据（包括数据库）！' #13#13 '如需保留数据，请先备份。', mbInformation, MB_OK);
  end;
end;
