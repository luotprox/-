@echo off
chcp 65001 >nul
title 银行存款机 — 一键启动

echo ========================================
echo   银行存款机 — 一键启动（前台模式）
echo   关闭本窗口即可停止服务
echo ========================================
echo.

cd /d "%~dp0..\server"

:: 检查 node_modules
if not exist "node_modules" (
    echo [*] 首次运行，正在安装依赖...
    call npm install
    if %errorLevel% neq 0 (
        echo [错误] 请先安装 Node.js: https://nodejs.org/
        pause
        exit /b 1
    )
)

:: 检查数据库是否初始化（简单检测 users 表是否存在）
echo [*] 检查数据库...
node -e "const p=require('./db');p.execute('SELECT 1 FROM users LIMIT 1').then(()=>process.exit(0)).catch(()=>{require('./init-db');process.exit(1)})" >nul 2>&1

echo [*] 启动服务器...
echo.
start http://127.0.0.1:3001/
node server.js

pause
